create procedure p7()
  BEGIN
SELECT * FROM `employee`;
END;

