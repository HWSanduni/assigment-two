create procedure p9(OUT minP double, OUT maxP double, OUT avgP double)
  BEGIN
select min(price)
into minP
from item;
select max(price)
into maxP
from item;
select avg(price)
into avgP
from item;
END;

