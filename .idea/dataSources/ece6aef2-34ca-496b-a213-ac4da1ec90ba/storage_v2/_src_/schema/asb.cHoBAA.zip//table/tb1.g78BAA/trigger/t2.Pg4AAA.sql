create trigger t2
  before INSERT
  on tb1
  for each row
  begin
insert into tb2 set a2 = New.a1;
END;

