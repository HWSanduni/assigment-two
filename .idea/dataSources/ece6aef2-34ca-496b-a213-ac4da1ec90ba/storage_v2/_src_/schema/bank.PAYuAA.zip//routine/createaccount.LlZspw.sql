create procedure createAccount(IN id int, IN odate date, IN atype varchar(20))
  BEGIN
IF(id!="" AND odate!="" AND atype!="") THEN
INSERT INTO account_relation VALUES(
id,odate,atype);

SELECT "Account successfully created!";
ELSE
SELECT "Please enter valid details";
END IF;
END;

