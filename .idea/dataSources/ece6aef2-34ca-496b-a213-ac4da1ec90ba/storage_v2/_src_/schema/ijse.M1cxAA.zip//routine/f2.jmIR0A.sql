create function f2(name varchar(100))
  returns text
  BEGIN
RETURN name;
END;

