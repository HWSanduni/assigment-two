create function f5()
  returns int
  BEGIN
declare count int;
select count(*) from employee where salary >= 20000.00 into count;
return count;
END;

