create function f4(val int)
  returns int
  BEGIN
declare var1 int;
select f3() into var1;
return var1+val;
END;

