create function f1()
  returns text
  BEGIN
RETURN 'hello ijse ';
END;

