create function f3()
  returns int
  BEGIN
RETURN 20;
END;

